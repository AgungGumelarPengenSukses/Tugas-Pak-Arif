<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <style>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        
        body {
            background: linear-gradient(160deg, #667eea 0%, #764ba2 200%);
            background-image : url(gung.png);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            background-size: cover;
            background-repeat: no-repeat;
        }

       
        .register-card {
            background: rgba(217, 90, 90, 0.33);
            background-filter: blur(3px);
            width: 100%;
            max-width: 450px;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05); /* Efek bayangan lembut */
        }

        .register-card h2 {
            text-align: center;
            color: #1f2937;
            margin-bottom: 25px;
            font-size: 24px;
        }

        
        .input-group {
            margin-bottom: 10px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #4b5563;
            font-size: 14px;
            font-weight: 600;
        }

        
        .input-group input, 
        .input-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 15px;
            color: #374151;
            background-color: #f9fafb;
            transition: all 0.3s ease;
        }

        
        .input-group input:focus, 
        .input-group select:focus {
            outline: none;
            border-color: #3b82f6; 
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        
        button {
            width: 100%;
            padding: 12px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2563eb;
        }

        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #140a81;
        }

        .login-link a {
            color: #cef63b;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        
        @media (max-width: 480px) {
            .register-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

    
    <div class="register-card">
        <h2>Form Pendaftaran</h2>
        
        <form action="proses_regis.php" method="POST">
            
            <div class="input-group">
         <label for="nama">NAMA:</label>
                <input type="text" id="nama" name="nama" required placeholder="Masukkan nama lengkap">
            </div>

            <div class="input-group">
                <label for="username">USERNAME:</label>
                <input type="text" id="username" name="username" required placeholder="Pilih username">
            </div>

            <div class="input-group">
                <label for="email">EMAIL:</label>
                <input type="email" id="email" name="email" required placeholder="contoh@email.com">
            </div>

            <div class="input-group">
                <label for="password">PASSWORD:</label>
                <input type="password" id="password" name="password" required placeholder="Buat password">
            </div>

            <div class="input-group">
                <label for="konfirmasi_password">KONFIRMASI_PASSWORD:</label>
                <input type="password" id="konfirmasi_password" name="konfirmasi_password" required placeholder="Ulangi password">
            </div>
            <div class="input-group">
                <label for="role">Daftar Sebagai Member Woilah:</label>
                <select id="role" name="role" required>
                    <option value="" disabled selected>-- Pilih ROLE --</option>
                    <option value="siswa">Siswa</option>
                    <option value="guru">Guru</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit">Daftar Sekarang</button>
        </form>

        <p class="login-link">Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>

</body>
</html>