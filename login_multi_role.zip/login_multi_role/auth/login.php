<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    
    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");

    
    if (mysqli_num_rows($query) === 1) {
        $row = mysqli_fetch_assoc($query);

        
        if (password_verify($password, $row['password'])) {

            
            $_SESSION['id'] = $row['id'];
            $_SESSION['nama'] = $row['nama'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];

            
            if ($row['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } elseif ($row['role'] == 'guru') {
                header("Location: ../guru/dashboard.php");
            } else {
                header("Location: ../siswa/dashboard.php");
            }
            exit;

        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak terdaftar!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <style>
        /* Reset dasar agar tampilan konsisten di semua browser */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Mengatur background dan memposisikan form di tengah layar */
        body {
            background: linear-gradient(160deg, #667eea 0%, #764ba2 200%);
            background-image : url(gung.png);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            background-size: cover;
            background-repeat: no-repeat;
        }

        /* Desain kotak form (Card) */
        .login-card {
            background: rgba(194, 16, 16, 0.38);
            background-filter: blur(3px);
            width: 100%;
            max-width: 450px;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05); /* Efek bayangan lembut */
        }

        .login-card h2 {
            text-align: center;
            color: #1f2937;
            margin-bottom: 25px;
            font-size: 24px;
        }

        /* Grup input untuk mengatur jarak antar field */
        .input-group {
            margin-bottom: 10px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #4b5563;
            font-size: 14px;
            font-weight: 600;
        }

        /* Styling untuk input teks, email, password, dan select */
        .input-group input, 
        .input-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 15px;
            color: #374151;
            background-color: #f9fafb;
            transition: all 0.3s ease;
        }

        /* Efek ketika input sedang diisi (Fokus) */
        .input-group input:focus, 
        .input-group select:focus {
            outline: none;
            border-color: #3b82f6; 
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        /* Styling Tombol Submit */
        button {
            width: 100%;
            padding: 12px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2563eb; /* Warna biru lebih gelap saat di-hover */
        }

        /* Styling teks link login di bawah */
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #140a81;
        }

        .login-link a {
            color: #cef63b;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        /* Responsif untuk layar HP kecil */
        @media (max-width: 480px) {
            .register-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

   
<div class="login-card">
    <h2>Silahkan Login</h2>
    <?php if (isset($error)) echo "<p style= 'color:red;'>$error</p>"; ?>
    <form method="POST" action="">
        <div class="input-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required placeholder="Masukkan username Anda">
        </div>

        <div class="input-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required placeholder="Masukkan password Anda">
        </div>
        <button type="sumbit" name="login">Login></button>
    </form>

    <p class="login-link">Belum punya akun? <a href="proses_register.php">Daftar di sini</a></p>
</div>

</body>
</html>