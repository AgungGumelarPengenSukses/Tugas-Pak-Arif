<?php

require_once '../config/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $konfirmasi = $_POST['konfirmasi_password'];
    $role = $_POST['role'];

    if ($password !== $konfirmasi) {
        echo "<script>alert('Password dan Konfirmasi tidak cocok!'); window.location='register.php'<script>";
        exit;
    }

    $cek_user = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($cek_user) > 0) {
        echo "<script>alert('Username atau Email sudah diguanakan!'); window.location='register.php'</script>";
        exit;
    }

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO users (nama, username, email, password, role) VALUE ('$nama', '$username', '$email', '$password_hashed', '$role')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Register Berhasil Silahkan Login.'); window.location='login.php'</script>";
    } else {
        echo "Error : " . mysqli_error($conn); 
    }
}