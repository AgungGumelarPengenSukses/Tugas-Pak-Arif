<?php
session_start();

if (!isset($_SESSION['role'])) {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SESSION['role'] != 'admin') {
    die("Akses Ditolak! Anda bukan Admin. <a href='../auth/logout.php'>Logout</a>");
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <style>
        /* Reset dasar agar tampilan konsisten di semua browser */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        
        body {
            background: linear-gradient(160deg, #667eea 0%, #764ba2 200%);
            background-image: url(a.jpeg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            background-size: cover;
            background-repeat: no-repeat;
        }

        
        .dashboard-card {
            background: rgba(86, 255, 1, 0.38);
            background-filter: blur(3px);
            width: 100%;
            max-width: 450px;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
        }

        .dashboard-card h2 {
            text-align: center;
            color: #ff0000;
            margin-bottom: 25px;
            font-size: 24px;
        }

        
        .input-group {
            margin-bottom: 10px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #4b5563;
            font-size: 14px;
            font-weight: 600;
        }

        /* Styling untuk input teks, email, password, dan select */
        .input-group input, 
        .input-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 15px;
            color: #ff0000;
            background-color: #f9fafb;
            transition: all 0.3s ease;
        }

        /* Efek ketika input sedang diisi (Fokus) */
        .input-group input:focus, 
        .input-group select:focus {
            outline: none;
            border-color: #3b82f6; 
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        /* Styling Tombol Submit */
        button {
            width: 100%;
            padding: 12px;
            background-color: #f63b3b;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #eb2525;
        }

        /* Styling teks link login di bawah */
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #c30f0f;
        }

        .login-link a {
            color: #cef63b;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        /* Responsif untuk layar HP kecil */
        @media (max-width: 480px) {
            .dashboard-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>

<head><title>Dashboard Admin</title></head>

    <div class="dashboard-card">
<body>
        <h1> <span style="color: #000000;">Selamat Datang, Adminstrator 
            <?php echo $_SESSION['nama']; ?></h>
        <p> <span style="color: #000000;">Anda login sebagai: <?php echo $_SESSION['role']; ?></p>

    <div style="text-align: center;">
        
        <a href="../auth/logout.php">[ Logout ]</a>
    </div>
        
</body>

</div>
</html>
